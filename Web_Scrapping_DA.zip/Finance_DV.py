#Finance data

import pandas as pd
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import *

Finance_Data={
    'Finance':['GDP_Japan','GDP_Germany'],
    'GDP':[4.2,4.5], #Trillion
    'GDP_Old_2000':[4.7,1.9],#Trillion
    'GDP_Growth':[0.5,0.3], #in percent
    'GDP_Growth_2000':[2.8,2.9],#in percent
    'Highest_GDP':[5.3,4.5],#in trillion
    'Exported_Value':[9.6,1.6], #japanies , Trillion
    'FDI':[1.5,981],#in Trillion and billion
    'Inflation':[3.4,5.9] #Percent
}

#create a DataFrame from the data
Finance_df=pd.DataFrame(Finance_Data)

window=tk.Tk()
window.title('Basic analysis of GDP data')
window.geometry('640x800+400+0')

#Basic analysis of GDP Data
#print('Basic analysis of GDP data')
#print()
h=tk.Label(window,text='Basic analysis of GDP data',font='arial 18 bold',bg='skyblue')
h.grid(row=0,column=0,columnspan=5,sticky='nsew',padx=10,pady=10)

#GDP as per january 2024
#print('1.GDP as per january 2024 in Trillion')
#print(Finance_df[['Finance','GDP']])
#print()
res1=tk.Label(window,text='1.GDP as per january 2024 in Trillion',font='sans 14 bold',bg='lightgreen')
res1.grid(row=1,column=0,columnspan=2,padx=10,pady=10,sticky='nsew')

FG=(Finance_df[['Finance','GDP']])
FG_L=tk.Label(window,text=FG,font='sans 12 bold')
FG_L.grid(row=2,column=0)

#GDP as per 2000
#print('2.GDP old data in Trillon')
#print(Finance_df[['Finance','GDP_Old_2000']])
#print()
res2=tk.Label(window,text='2.GDP old data in Trillon',font='sans 14 bold',bg='lightgreen')
res2.grid(row=3,column=0,columnspan=2,padx=10,pady=10,sticky='nsew')

FG_old=(Finance_df[['Finance','GDP_Old_2000']])
FG_old=tk.Label(window,text=FG_old,font='sans 12 bold')
FG_old.grid(row=4,column=0)

#GDP Growth
#print('3.GDP Growth in Perccent')
#print(Finance_df[['Finance','GDP_Growth']])
#print()
res3=tk.Label(window,text='3.GDP Growth in Perccent',font='sans 14 bold',bg='lightgreen')
res3.grid(row=5,column=0,columnspan=2,padx=10,pady=10,sticky='nsew')

FG_G=(Finance_df[['Finance','GDP_Growth']])
FG_G=tk.Label(window,text=FG_G,font='sans 12 bold')
FG_G.grid(row=6,column=0)

#GDP Highest
#print('4.Highest GDP in 2023 in Billion')
#print(Finance_df[['Finance','Highest_GDP']])
#print()
res4=tk.Label(window,text='4.Highest GDP in 2023 in Billion',font='sans 14 bold',bg='lightgreen')
res4.grid(row=7,column=0,columnspan=2,padx=10,pady=10,sticky='nsew')

FG_H=(Finance_df[['Finance','Highest_GDP']])
FG_H=tk.Label(window,text=FG_H,font='sans 12 bold')
FG_H.grid(row=8,column=0)

#Exported value
#print('5.Exported value in Trillion')
#print(Finance_df[['Finance','Exported_Value']])
#print()
res5=tk.Label(window,text='5.Exported value in Trillion',font='sans 14 bold',bg='lightgreen')
res5.grid(row=1,column=3,columnspan=2,padx=10,pady=10,sticky='nsew')

FG_E=(Finance_df[['Finance','Exported_Value']])
FG_E=tk.Label(window,text=FG_E,font='sans 12 bold')
FG_E.grid(row=2,column=3)

#FDI
#print('6.FDI in Trillion and Billion')
#print(Finance_df[['Finance','FDI']])
#print()
res6=tk.Label(window,text='6.FDI in Trillion and Billion',font='sans 14 bold',bg='lightgreen')
res6.grid(row=3,column=3,columnspan=2,padx=10,pady=10,sticky='nsew')

FG_F=(Finance_df[['Finance','FDI']])
FG_F=tk.Label(window,text=FG_F,font='sans 12 bold')
FG_F.grid(row=4,column=3)

#Inflation in 2023
#print('7.FDI in 2023 Percent')
#print(Finance_df[['Finance','Inflation']])
#print()
res7=tk.Label(window,text='7.FDI in 2023 Percent',font='sans 14 bold',bg='lightgreen')
res7.grid(row=3,column=3,columnspan=2,padx=10,pady=10,sticky='nsew')

FG_F=(Finance_df[['Finance','Inflation']])
FG_F=tk.Label(window,text=FG_F,font='sans 12 bold')
FG_F.grid(row=4,column=3)

bt=tk.Button(window,width=10,height=2,text='Exit',font='sans 12 bold',bg='black',fg='white',command=window.destroy)
bt.grid(row=9,columnspan=4,padx=10,pady=10)

#Plotting on GDP as per january 2024 in Trillion
plt.figure(figsize=(10,5))
plt.bar(Finance_df['Finance'],Finance_df['GDP'],color=['orange','green'])
plt.xlabel('Finance')
plt.ylabel('GDP')
plt.title("GDP as per january 2024 in Trillion")
plt.ylim(0,5) #Setting y-axis limit for better visualization
plt.xticks(rotation=45)
plt.grid(axis='y',linestyle='--',alpha=0.7)
plt.tight_layout()
plt.show()

#Plotting on gdp
plt.figure(figsize=(10,5))
plt.bar(Finance_df['Finance'],Finance_df['GDP_Old_2000'],color=['skyblue','lightgreen'])
plt.xlabel('Finance')
plt.ylabel('GDP_Old_2000')
plt.title("GDP as per january 2000 in Trillion")
plt.ylim(0,5) #Setting y-axis limit for better visualization
plt.xticks(rotation=45)
plt.grid(axis='y',linestyle='--',alpha=0.7)
plt.tight_layout()
plt.show()

window.mainloop()
