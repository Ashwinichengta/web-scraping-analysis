# Technology Analysis - Data science application

import pandas as pd
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import *

Cmpny_data={
    'Company_name':['TCS','Infosys'],
    'Founded':['1968','1981'],
    'Founder':['Jehangir Ratanji Dadabhoy Tata','Narayan Murthy'],
    'Headquaters':['Mumbai','Bangaluru'],
    'Total_countries':[55,56],
    'Market_capitalization':[200,100],
    'Revenue_in_2023':[28.9,18.5],
    'Total_Asset_2023':[18.6,15.6],
    'Number_of_Employee':[614795,336294]
}

#create a data frame from the data
Cpny_df=pd.DataFrame(Cmpny_data)

window=tk.Tk()
window.title('Basic analysis of Technology')
window.geometry('850x900+300+0')

#Basic analysis of Sports data
#print('Basic analysis of Technology :')
#print()
h=tk.Label(window,text='Basic analysis of Technology',font='arial 18 bold',bg='skyblue')
h.grid(row=0,column=0,columnspan=5,sticky='nsew',padx=10,pady=10)

#1.Name and founded
#print('1. Company Name and founded year :')
#print(Cpny_df[['Company_name','Founded']])
#print()
res1=tk.Label(window,text='1. Company Name and founded year',font='sans 14 bold',bg='lightgreen')
res1.grid(row=1,column=0,columnspan=2,padx=10,pady=10,sticky='nsew')

FG=(Cpny_df[['Company_name','Founded']])
FG_L=tk.Label(window,text=FG,font='sans 12 bold')
FG_L.grid(row=2,column=0)

#2.Name and Founder
#print('2. Company Name and founder :')
#print(Cpny_df[['Company_name','Founder']])
#print()
res2=tk.Label(window,text='2. Company Name and founder',font='sans 14 bold',bg='lightgreen')
res2.grid(row=3,column=0,columnspan=2,padx=10,pady=10,sticky='nsew')

FG=(Cpny_df[['Company_name','Founder']])
FG_L=tk.Label(window,text=FG,font='sans 12 bold')
FG_L.grid(row=4,column=0)

#3.Name and headquatoers
#print('3. Company Name and Headquaters :')
#print(Cpny_df[['Company_name','Headquaters']])
#print()
res3=tk.Label(window,text='3. Company Name and Headquaters',font='sans 14 bold',bg='lightgreen')
res3.grid(row=5,column=0,columnspan=2,padx=10,pady=10,sticky='nsew')

FG=(Cpny_df[['Company_name','Headquaters']])
FG_L=tk.Label(window,text=FG,font='sans 12 bold')
FG_L.grid(row=6,column=0)

#4.Name and Total Employees
#print('4. Company Name and Total Employees :')
#print(Cpny_df[['Company_name','Number_of_Employee']])
#print()
res4=tk.Label(window,text='4. Company Name and Total Employees',font='sans 14 bold',bg='lightgreen')
res4.grid(row=7,column=0,columnspan=2,padx=10,pady=10,sticky='nsew')

FG=(Cpny_df[['Company_name','Number_of_Employee']])
FG_L=tk.Label(window,text=FG,font='sans 12 bold')
FG_L.grid(row=8,column=0)

#5.Name and Total countries
#print('5. Company Name and Total Countries :')
#print(Cpny_df[['Company_name','Total_countries']])
#print()
res5=tk.Label(window,text='5. Company Name and Total Countries',font='sans 14 bold',bg='lightgreen')
res5.grid(row=1,column=3,columnspan=2,padx=10,pady=10,sticky='nsew')

FG=(Cpny_df[['Company_name','Total_countries']])
FG_L=tk.Label(window,text=FG,font='sans 12 bold')
FG_L.grid(row=2,column=3)

#6.Name and assets
#print('6. Company Name and Total Asset in Billion:')
#print(Cpny_df[['Company_name','Total_Asset_2023']])
#print()
res6=tk.Label(window,text='6. Company Name and Total Asset in Billion',font='sans 14 bold',bg='lightgreen')
res6.grid(row=3,column=3,columnspan=2,padx=10,pady=10,sticky='nsew')

FG=(Cpny_df[['Company_name','Total_countries']])
FG_L=tk.Label(window,text=FG,font='sans 12 bold')
FG_L.grid(row=4,column=3)

#7.Name and Revenue
#print('7. Company Name and Revenue in Billion:')
#print(Cpny_df[['Company_name','Revenue_in_2023']])
#print()
res7=tk.Label(window,text='7. Company Name and Revenue in Billion',font='sans 14 bold',bg='lightgreen')
res7.grid(row=5,column=3,columnspan=2,padx=10,pady=10,sticky='nsew')

FG=(Cpny_df[['Company_name','Revenue_in_2023']])
FG_L=tk.Label(window,text=FG,font='sans 12 bold')
FG_L.grid(row=6,column=3)

#8.Name and Market Capitalization
#print('8. Company Name and Market Capitalization in Billion :')
#print(Cpny_df[['Company_name','Market_capitalization']])
#print()
res8=tk.Label(window,text='8.Name and Market Capitalization in Billion',font='sans 14 bold',bg='lightgreen')
res8.grid(row=7,column=3,columnspan=2,padx=10,pady=10,sticky='nsew')

FG=(Cpny_df[['Company_name','Market_capitalization']])
FG_L=tk.Label(window,text=FG,font='sans 12 bold')
FG_L.grid(row=8,column=3)

bt=tk.Button(window,width=10,height=2,text='Exit',font='sans 12 bold',bg='black',fg='white',command=window.destroy)
bt.grid(row=9,columnspan=4,padx=10,pady=10)

#Plotting on Market capitalization
plt.figure(figsize=(10,5))
plt.bar(Cpny_df['Company_name'],Cpny_df['Market_capitalization'],color=['orange','green'])
plt.xlabel('Company_name')
plt.ylabel('Market_capitalization')
plt.title("Company name and Market capitalization in Billion")
plt.ylim(0,250) #Setting y-axis limit for better visualization
plt.xticks(rotation=45)
plt.grid(axis='y',linestyle='--',alpha=0.7)
plt.tight_layout()
plt.show()

#Plotting total winners price money
plt.figure(figsize=(10,5))
plt.bar(Cpny_df['Company_name'],Cpny_df['Revenue_in_2023'],color=['skyblue','lightgreen'])
plt.xlabel('Company_name')
plt.ylabel('Revenue_in_2023')
plt.title('Company name and Revenue in Billion')
plt.ylim(0.50) #setting y-axis limit for the better visualization
plt.xticks(rotation=36)
plt.grid(axis='y',linestyle='--',alpha=0.7)
plt.tight_layout()
plt.show()

window.mainloop()
