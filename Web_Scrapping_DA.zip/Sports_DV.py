# Sports analysis - Data science application

import pandas as pd
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import *

Sports_data={
    'Sports':['Cricket','Football'],
    'Playing_countries':[85,205],
    'Top_Continent':['Asia','America'],
    'Views':[2.5,3.5],
    'Playing_time':[10,1.3],
    'Popular_league':['ICC World Cup','Fifa World Cup'],
    'Price_money':[10,42],
    'Revenue_generation':[9.5,14],
    'Market_size':[2.9,3.3]
}

#create a dataframe from the data
Sports_df=pd.DataFrame(Sports_data)

window=tk.Tk()
window.title('Polytical Data Analysis')
window.geometry('640x800+400+0')

#Basic analysis of Sports data
#print('Basic analysis of sports teams:')
#print()

h=tk.Label(window,text='Basic analysis of sports teams',font='arial 18 bold',bg='skyblue')
h.grid(row=0,column=0,columnspan=5,sticky='nsew',padx=10,pady=10)

#1.Popular league
#print('1. Popular Leagues:')
#print(Sports_df[['Sports','Popular_league']])
#print()

PI=tk.Label(window,text='1. Popular Leagues',font='sans 14 bold',bg='lightgreen')
PI.grid(row=1,column=0,columnspan=2,padx=10,pady=10,sticky='nsew')

RPI=(Sports_df[['Sports','Popular_league']])
RPI_L=tk.Label(window,text=RPI,font='sans 12 bold')
RPI_L.grid(row=2,column=0)

#2. Top Continents
#print('2. Top Continent:')
#print(Sports_df[['Sports','Top_Continent']])
#print()

PI=tk.Label(window,text='2. Top Continent',font='sans 14 bold',bg='lightgreen')
PI.grid(row=3,column=0,columnspan=2,padx=10,pady=10,sticky='nsew')

RPI=(Sports_df[['Sports','Top_Continent']])
RPI_L=tk.Label(window,text=RPI,font='sans 12 bold')
RPI_L.grid(row=4,column=0)

#3.Total playing countries
#print('3. Total Playing countries:')
#print(Sports_df[['Sports','Playing_countries']])
#print()

PI=tk.Label(window,text='3. Total Playing countries',font='sans 14 bold',bg='lightgreen')
PI.grid(row=5,column=0,columnspan=2,padx=10,pady=10,sticky='nsew')

RPI=(Sports_df[['Sports','Playing_countries']])
RPI_L=tk.Label(window,text=RPI,font='sans 12 bold')
RPI_L.grid(row=6,column=0)

#4. Total views in billion
#print('4. Total Views in Billion:')
#print(Sports_df[['Sports','Views']])
#print()

PI=tk.Label(window,text='4. Total Views in Billion',font='sans 14 bold',bg='lightgreen')
PI.grid(row=7,column=0,columnspan=2,padx=10,pady=10,sticky='nsew')

RPI=(Sports_df[['Sports','Views']])
RPI_L=tk.Label(window,text=RPI,font='sans 12 bold')
RPI_L.grid(row=8,column=0)

#5. Total Money in Million
#print('5. Winner Price Money in Million')
#print(Sports_df[['Sports','Price_money']])
#print()

PI=tk.Label(window,text='5. Winner Price Money in Million',font='sans 14 bold',bg='lightgreen')
PI.grid(row=1,column=3,columnspan=2,padx=10,pady=10,sticky='nsew')

RPI=(Sports_df[['Sports','Price_money']])
RPI_L=tk.Label(window,text=RPI,font='sans 12 bold')
RPI_L.grid(row=2,column=3)

#6. Revenue generation
#print('6. Total Revenue Generation in Billion')
#print(Sports_df[['Sports','Revenue_generation']])
#print()

PI=tk.Label(window,text='6. Total Revenue Generation in Billion',font='sans 14 bold',bg='lightgreen')
PI.grid(row=3,column=3,columnspan=2,padx=10,pady=10,sticky='nsew')

RPI=(Sports_df[['Sports','Revenue_generation']])
RPI_L=tk.Label(window,text=RPI,font='sans 12 bold')
RPI_L.grid(row=4,column=3)

#7. Market size
#print('7. Market Size Million and Billion')
#print(Sports_df[['Sports','Market_size']])
#print()

PI=tk.Label(window,text='7. Market Size Million and Billion',font='sans 14 bold',bg='lightgreen')
PI.grid(row=5,column=3,columnspan=2,padx=10,pady=10,sticky='nsew')

RPI=(Sports_df[['Sports','Market_size']])
RPI_L=tk.Label(window,text=RPI,font='sans 12 bold')
RPI_L.grid(row=6,column=3)

bt=tk.Button(window,width=10,height=2,text='Exit',font='sans 12 bold',bg='black',fg='white',command=window.destroy)
bt.grid(row=9,columnspan=4,padx=10,pady=10)

#Plotting no of playing countries
plt.figure(figsize=(10,5))
plt.bar(Sports_df['Sports'],Sports_df['Playing_countries'],color=['orange','green'])
plt.xlabel('Sports')
plt.ylabel('Playing_countries')
plt.title("Highest sports playing countries")
plt.ylim(0,250) #Setting y-axis limit for better visualization
plt.xticks(rotation=45)
plt.grid(axis='y',linestyle='--',alpha=0.7)
plt.tight_layout()
plt.show()

#Plotting total winners price money
plt.figure(figsize=(10,5))
plt.bar(Sports_df['Sports'],Sports_df['Price_money'],color=['skyblue','lightgreen'])
plt.xlabel('Sports')
plt.ylabel('Price_money')
plt.title('Winners Price Money in Million')
plt.ylim(0.50) #setting y-axis limit for the better visualization
plt.xticks(rotation=45)
plt.grid(axis='y',linestyle='--',alpha=0.7)
plt.tight_layout()
plt.show()

window.mainloop()
