import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import os
import time

class Dashboard(tk.Tk):
    def __init__(self):
        super(). __init__()
        self.title("Data analytics and Data visualization")
        self.geometry("1350x720")

        #Load and display image
        self.load_image("emp2.PNG")

        #create menu
        self.menu = tk.Menu(self)
        self.config(menu=self.menu)

        #create Political data analytics menu
        self.da_menu=tk.Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label="Polytical Data",menu=self.da_menu)
        self.da_menu.add_command(label="Show Data",command=self.open_Political_DV)
        self.da_menu.add_separator()
        self.da_menu.add_command(label="Exit",command=self.destroy)

        #create Technology data analytics menu
        self.da_menu=tk.Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label="Technology Data",menu=self.da_menu)
        self.da_menu.add_command(label="Show Data",command=self.open_Technology_DV)
        self.da_menu.add_separator()
        self.da_menu.add_command(label="Exit",command=self.destroy)

        #create Sports data analytics menu
        self.da_menu=tk.Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label="Sports Data",menu=self.da_menu)
        self.da_menu.add_command(label="Show Data",command=self.open_Sports_DV)
        self.da_menu.add_separator()
        self.da_menu.add_command(label="Exit",command=self.destroy)

        #create Finanace data analytics menu
        self.da_menu=tk.Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label="Finanace Data",menu=self.da_menu)
        self.da_menu.add_command(label="Show Data",command=self.open_Finanace_DV)
        self.da_menu.add_separator()
        self.da_menu.add_command(label="Exit",command=self.destroy)

    def load_image(self, image_path):
        image=Image.open(image_path)
        image=image.resize((800,500))
        self.dashboard_image=ImageTk.PhotoImage(image)
        self.image_label=tk.Label(self,image=self.dashboard_image)
        hd=tk.Label(self, text="Data Analysis",bg='orange',fg='green',font=('sans bold',16)).pack(fill="both")
        self.image_label.pack()
        sd=tk.Label(self, text='Developed by ANIL ERANNA',bg='green',fg='white',font=('sans bold',16)).pack(fill="both")

        #Importing python files
    def open_Political_DV(self):
        #Existing files
        import Political_DV as PD

    def open_Technology_DV(self):
        #Existing files
        import Technology_DV as PD

    def open_Sports_DV(self):
        #Existing files
        import Sports_DV as PD

    def open_Finanace_DV(self):
        #Existing files
        import Finance_DV as PD

if __name__ == "__main__":
    app = Dashboard()
    app.mainloop()
